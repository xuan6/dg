
def setUp():
    import socket
    socket.setdefaulttimeout(5)
